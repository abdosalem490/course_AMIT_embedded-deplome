#ifndef DIO_INTERFACE_H_
#define DIO_INTERFACE_H_

/*PORTS*/
#define DIO_u8_PORTA	0
#define DIO_u8_PORTB	1
#define DIO_u8_PORTC	2
#define DIO_u8_PORTD	3

/*PINS*/
#define DIO_u8_PIN0		0
#define DIO_u8_PIN1		1
#define DIO_u8_PIN2		2
#define DIO_u8_PIN3		3
#define DIO_u8_PIN4		4
#define DIO_u8_PIN5		5
#define DIO_u8_PIN6		6
#define DIO_u8_PIN7		7

/*PIN STATUS*/
#define DIO_u8_PIN_HIGH  1
#define DIO_u8_PIN_LOW   0

/*PIN IN OR OUT*/
#define DIO_u8_PIN_OUTPUT  1
#define DIO_u8_PIN_INPUT   0

/*LED DIRECTION*/
#define DIO_u8_LED_FORWARD	 1
#define DIO_u8_LED_BACKWARD	 0

/*SWITCH PULL TYPRE*/
#define DIO_u8_PULL_UP		0
#define DIO_u8_PULL_DOWN	1

/*SWITCH STATUS*/
#define DIO_u8_SWITCH_PRESSED	1
#define DIO_u8_SWITCH_RELEASED  0

/*SSD TYPE*/
#define DIO_u8_SSD_TYPE_ANODE	1
#define DIO_u8_SSD_TYPE_CATHODE	0

/////////////////////////////////////////////
typedef struct{
	uint8 Local_u8Port;
	uint8 Local_u8Pin;
	uint8 Local_u8Direction;
}Led_Config_t;

typedef struct{
	uint8 Local_u8Port;
	uint8 Local_u8Pin;
	uint8 Local_u8PullType;
}SW_Config_t;

typedef struct{
	uint8 Local_u8DataPort;
	uint8 Local_u8PinA;
	uint8 Local_u8PinB;
	uint8 Local_u8PinC;
	uint8 Local_u8PinD;
	uint8 Local_u8EnablePort;
	uint8 Local_u8EnablePin;
	uint8 Local_u8Type;
}SSD_Config_t;
/////////////////////////////////////////////

uint8 DIO_u8SetPinValue(uint8 Copy_u8Port,uint8 Copy_u8PinNum,uint8 Copy_u8Val);
uint8 DIO_u8SetPortValue(uint8 Copy_u8Port,uint8 Copy_u8Val);

uint8 DIO_u8SetPinDirection(uint8 Copy_u8Port,uint8 Copy_u8PinNum,uint8 Copy_u8Dir);
uint8 DIO_u8SetPortDirection(uint8 Copy_u8Port,uint8 Copy_u8Dir);

uint8 DIO_u8ReadPinValue(uint8 Copy_u8Port,uint8 Copy_u8PinNum,uint8* Copy_pu8Value);

uint8 DIO_u8TogglePinValue(uint8 Copy_u8Port,uint8 Copy_u8PinNum);

//Led driver functions
uint8 LED_u8TurnON(const Led_Config_t* Copy_Pu8Object);
uint8 LED_u8TurnOFF(const Led_Config_t* Copy_Pu8Object);

//Switch driver functions
uint8 SW_u8GetState(const SW_Config_t* Copy_Pu8Object,uint8* Copy_Pu8State);

//SSD driver functions
uint8 SSD_u8Enable(const SSD_Config_t* Copy_Pu8Object);
uint8 SSD_u8Disable(const SSD_Config_t* Copy_Pu8Object);
uint8 SSD_u8SetNumber(const SSD_Config_t* Copy_Pu8Object , uint8 Copy_u8Number);

#endif
