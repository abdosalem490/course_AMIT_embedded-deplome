#include "STD_TYPES.h"
#include "BTT_MATH.h"
#include "ERR_TYPE.h"

#include "DIO_interface.h"
#include "DIO_reg.h"
#include "DIO_private.h"
#include "DIO_config.h"

//<--------------------PINS & PORTS-------------------->
uint8 DIO_u8SetPinValue(uint8 Copy_u8Port,uint8 Copy_u8PinNum,uint8 Copy_u8Val)
{
	uint8 Local_u8ErrorState = OK;
	if((Copy_u8PinNum <= DIO_u8_PIN7)&& (Copy_u8Val <= DIO_u8_PIN_HIGH)){
		switch(Copy_u8Port)
		{
			case DIO_u8_PORTA : ASSIGN_BIT(PORTA,Copy_u8PinNum,Copy_u8Val); break;
			case DIO_u8_PORTB : ASSIGN_BIT(PORTB,Copy_u8PinNum,Copy_u8Val); break;
			case DIO_u8_PORTC : ASSIGN_BIT(PORTC,Copy_u8PinNum,Copy_u8Val); break;
			case DIO_u8_PORTD : ASSIGN_BIT(PORTD,Copy_u8PinNum,Copy_u8Val); break;
			default : Local_u8ErrorState = NOK; break;
		}
	}
	else
	{
		Local_u8ErrorState = NOK;
	}
	return Local_u8ErrorState;
}

uint8 DIO_u8SetPortValue(uint8 Copy_u8Port,uint8 Copy_u8Val)
{
	uint8 Local_u8ErrorState = OK;
	switch(Copy_u8Port)
	{
		case DIO_u8_PORTA : PORTA = Copy_u8Val; break;
		case DIO_u8_PORTB : PORTB = Copy_u8Val; break;
 		case DIO_u8_PORTC : PORTC = Copy_u8Val; break;
		case DIO_u8_PORTD : PORTD = Copy_u8Val; break;
		default : Local_u8ErrorState = NOK; break;
	}
	return Local_u8ErrorState;
}

uint8 DIO_u8SetPinDirection(uint8 Copy_u8Port,uint8 Copy_u8PinNum,uint8 Copy_u8Dir)
{
	uint8 Local_u8ErrorState = OK;
	if((Copy_u8PinNum <= DIO_u8_PIN7)&& (Copy_u8Dir <= DIO_u8_PIN_HIGH)){
		switch(Copy_u8Port)
		{
			case DIO_u8_PORTA : ASSIGN_BIT(DDRA,Copy_u8PinNum,Copy_u8Dir); break;
			case DIO_u8_PORTB : ASSIGN_BIT(DDRB,Copy_u8PinNum,Copy_u8Dir); break;
			case DIO_u8_PORTC : ASSIGN_BIT(DDRC,Copy_u8PinNum,Copy_u8Dir); break;
			case DIO_u8_PORTD : ASSIGN_BIT(DDRD,Copy_u8PinNum,Copy_u8Dir); break;
			default : Local_u8ErrorState = NOK; break;
		}
	}
	else
	{
		Local_u8ErrorState = NOK;
	}
	return Local_u8ErrorState;
}

uint8 DIO_u8SetPortDirection(uint8 Copy_u8Port,uint8 Copy_u8Dir)
{
	uint8 Local_u8ErrorState = OK;
	switch(Copy_u8Port)
	{
		case DIO_u8_PORTA : DDRA = Copy_u8Dir; break;
		case DIO_u8_PORTB : DDRB = Copy_u8Dir; break;
 		case DIO_u8_PORTC : DDRC = Copy_u8Dir; break;
		case DIO_u8_PORTD : DDRD = Copy_u8Dir; break;
		default : Local_u8ErrorState = NOK; break;
	}
	return Local_u8ErrorState;
}

uint8 DIO_u8ReadPinValue(uint8 Copy_u8Port,uint8 Copy_u8PinNum,uint8* Copy_pu8Val)
{
	uint8 Local_u8ErrorState = OK;
	if((Copy_u8PinNum <= DIO_u8_PIN7) && (Copy_pu8Val != NULL)){
		switch(Copy_u8Port)
		{
			case DIO_u8_PORTA : *Copy_pu8Val = GET_BIT(PINA,Copy_u8PinNum); break;
			case DIO_u8_PORTB : *Copy_pu8Val = GET_BIT(PINB,Copy_u8PinNum); break;
			case DIO_u8_PORTC : *Copy_pu8Val = GET_BIT(PINC,Copy_u8PinNum); break;
			case DIO_u8_PORTD : *Copy_pu8Val = GET_BIT(PIND,Copy_u8PinNum); break;
			default : Local_u8ErrorState = NOK; break;
		}
	}
	else if(Copy_pu8Val == NULL)
	{
		Local_u8ErrorState  = NULL_POINTER;
	}
	else
	{
		Local_u8ErrorState = NOK;
	}
	return Local_u8ErrorState;
}

uint8 DIO_u8TogglePinValue(uint8 Copy_u8Port,uint8 Copy_u8PinNum)
{
	uint8 Local_u8ErrorState = OK;
	if(Copy_u8PinNum <= DIO_u8_PIN7){
		switch(Copy_u8Port)
		{
			case DIO_u8_PORTA : TOG_BIT(PORTA,Copy_u8PinNum); break;
			case DIO_u8_PORTB : TOG_BIT(PORTB,Copy_u8PinNum); break;
			case DIO_u8_PORTC : TOG_BIT(PORTC,Copy_u8PinNum); break;
			case DIO_u8_PORTD : TOG_BIT(PORTD,Copy_u8PinNum); break;
			default : Local_u8ErrorState = NOK; break;
		}
	}
	else
	{
		Local_u8ErrorState = NOK;
	}
	return Local_u8ErrorState;
}
//<------------------------------------------------------>

//<--------------------LEDS-------------------->
uint8 LED_u8TurnON(const Led_Config_t* Copy_Pu8Object){
	uint8 Local_u8ErrorState = OK;
	if(Copy_Pu8Object != NULL){
		if(Copy_Pu8Object->Local_u8Pin != NULL && Copy_Pu8Object->Local_u8Direction != NULL && Copy_Pu8Object->Local_u8Port != NULL){
			if(Copy_Pu8Object->Local_u8Pin <= DIO_u8_PIN7 && Copy_Pu8Object->Local_u8Direction <= DIO_u8_LED_FORWARD){
				switch(Copy_Pu8Object->Local_u8Port)
				{
					case DIO_u8_PORTA : {
						SET_BIT(DDRA,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_FORWARD) SET_BIT(PORTA,Copy_Pu8Object->Local_u8Pin);
						else if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_BACKWARD) CLR_BIT(PORTA,Copy_Pu8Object->Local_u8Pin);
					}  break;
					case DIO_u8_PORTB : {
						SET_BIT(DDRB,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_FORWARD) SET_BIT(PORTB,Copy_Pu8Object->Local_u8Pin);
						else if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_BACKWARD) CLR_BIT(PORTB,Copy_Pu8Object->Local_u8Pin);
					}  break;
					case DIO_u8_PORTC : {
						SET_BIT(DDRC,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_FORWARD) SET_BIT(PORTC,Copy_Pu8Object->Local_u8Pin);
						else if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_BACKWARD) CLR_BIT(PORTC,Copy_Pu8Object->Local_u8Pin);
					} break;
					case DIO_u8_PORTD : {
						SET_BIT(DDRD,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_FORWARD) SET_BIT(PORTD,Copy_Pu8Object->Local_u8Pin);
						else if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_BACKWARD) CLR_BIT(PORTD,Copy_Pu8Object->Local_u8Pin);
					} break;
					default : Local_u8ErrorState = NOK; break;
				}
			}else{
				Local_u8ErrorState = NOK;
			}
		}else{
			Local_u8ErrorState = MISSING_INFORM;
		}
	}else{
		Local_u8ErrorState = NULL_POINTER;
	}
	return Local_u8ErrorState;
}

uint8 LED_u8TurnOFF(const Led_Config_t* Copy_Pu8Object){
	uint8 Local_u8ErrorState = OK;
	if(Copy_Pu8Object != NULL){
		if(Copy_Pu8Object->Local_u8Pin != NULL && Copy_Pu8Object->Local_u8Direction != NULL && Copy_Pu8Object->Local_u8Port != NULL){
			if(Copy_Pu8Object->Local_u8Pin <= DIO_u8_PIN7 && Copy_Pu8Object->Local_u8Direction <= DIO_u8_LED_FORWARD){
				switch(Copy_Pu8Object->Local_u8Port)
				{
					case DIO_u8_PORTA : {
						SET_BIT(DDRA,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_FORWARD) CLR_BIT(PORTA,Copy_Pu8Object->Local_u8Pin);
						else if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_BACKWARD) SET_BIT(PORTA,Copy_Pu8Object->Local_u8Pin);
					}  break;
					case DIO_u8_PORTB : {
						SET_BIT(DDRB,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_FORWARD) CLR_BIT(PORTB,Copy_Pu8Object->Local_u8Pin);
						else if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_BACKWARD) SET_BIT(PORTB,Copy_Pu8Object->Local_u8Pin);
					}  break;
					case DIO_u8_PORTC : {
						SET_BIT(DDRC,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_FORWARD) CLR_BIT(PORTC,Copy_Pu8Object->Local_u8Pin);
						else if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_BACKWARD) SET_BIT(PORTC,Copy_Pu8Object->Local_u8Pin);
					} break;
					case DIO_u8_PORTD : {
						SET_BIT(DDRD,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_FORWARD) CLR_BIT(PORTD,Copy_Pu8Object->Local_u8Pin);
						else if(Copy_Pu8Object->Local_u8Direction == DIO_u8_LED_BACKWARD) SET_BIT(PORTD,Copy_Pu8Object->Local_u8Pin);
					} break;
					default : Local_u8ErrorState = NOK; break;
				}
			}else{
				Local_u8ErrorState = NOK;
			}
		}else{
			Local_u8ErrorState = MISSING_INFORM;
		}
	}else{
		Local_u8ErrorState = NULL_POINTER;
	}
	return Local_u8ErrorState;
}
//<------------------------------------------------------>

//<--------------------SWITCH-------------------->
uint8 SW_u8GetState(const SW_Config_t* Copy_Pu8Object,uint8* Copy_Pu8State){
	uint8 Local_u8ErrorState = OK;
	if(Copy_Pu8Object != NULL && Copy_Pu8State != NULL){
		if(Copy_Pu8Object->Local_u8Port != NULL && Copy_Pu8Object->Local_u8Pin != NULL && Copy_Pu8Object->Local_u8PullType != NULL){
			if(Copy_Pu8Object->Local_u8Pin <= DIO_u8_PIN7 && Copy_Pu8Object->Local_u8PullType <= DIO_u8_PULL_DOWN){
				switch(Copy_Pu8Object->Local_u8Port)
				{
					case DIO_u8_PORTA : {
						CLR_BIT(DDRA,Copy_Pu8Object->Local_u8Pin);
						uint8 Local_u8ValueOfPIN = GET_BIT(PINA,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8PullType == DIO_u8_PULL_DOWN && Local_u8ValueOfPIN == DIO_u8_PIN_HIGH)
							*Copy_Pu8State = DIO_u8_SWITCH_PRESSED;
						else if(Copy_Pu8Object->Local_u8PullType == DIO_u8_PULL_UP && Local_u8ValueOfPIN == DIO_u8_PIN_LOW)
							*Copy_Pu8State = DIO_u8_SWITCH_PRESSED;
						else
							*Copy_Pu8State = DIO_u8_SWITCH_RELEASED;
					}  break;
					case DIO_u8_PORTB : {
						CLR_BIT(DDRB,Copy_Pu8Object->Local_u8Pin);
						uint8 Local_u8ValueOfPIN = GET_BIT(PINB,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8PullType == DIO_u8_PULL_DOWN && Local_u8ValueOfPIN == DIO_u8_PIN_HIGH)
							*Copy_Pu8State = DIO_u8_SWITCH_PRESSED;
						else if(Copy_Pu8Object->Local_u8PullType == DIO_u8_PULL_UP && Local_u8ValueOfPIN == DIO_u8_PIN_LOW)
							*Copy_Pu8State = DIO_u8_SWITCH_PRESSED;
						else
							*Copy_Pu8State = DIO_u8_SWITCH_RELEASED;
					}  break;
					case DIO_u8_PORTC : {
						CLR_BIT(DDRC,Copy_Pu8Object->Local_u8Pin);
						uint8 Local_u8ValueOfPIN = GET_BIT(PINC,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8PullType == DIO_u8_PULL_DOWN && Local_u8ValueOfPIN == DIO_u8_PIN_HIGH)
							*Copy_Pu8State = DIO_u8_SWITCH_PRESSED;
						else if(Copy_Pu8Object->Local_u8PullType == DIO_u8_PULL_UP && Local_u8ValueOfPIN == DIO_u8_PIN_LOW)
							*Copy_Pu8State = DIO_u8_SWITCH_PRESSED;
						else
							*Copy_Pu8State = DIO_u8_SWITCH_RELEASED;
					} break;
					case DIO_u8_PORTD : {
						CLR_BIT(DDRD,Copy_Pu8Object->Local_u8Pin);
						uint8 Local_u8ValueOfPIN = GET_BIT(PIND,Copy_Pu8Object->Local_u8Pin);
						if(Copy_Pu8Object->Local_u8PullType == DIO_u8_PULL_DOWN && Local_u8ValueOfPIN == DIO_u8_PIN_HIGH)
							*Copy_Pu8State = DIO_u8_SWITCH_PRESSED;
						else if(Copy_Pu8Object->Local_u8PullType == DIO_u8_PULL_UP && Local_u8ValueOfPIN == DIO_u8_PIN_LOW)
							*Copy_Pu8State = DIO_u8_SWITCH_PRESSED;
						else
							*Copy_Pu8State = DIO_u8_SWITCH_RELEASED;
					} break;
					default : Local_u8ErrorState = NOK; break;
				}
			}else{
			Local_u8ErrorState = NOK;
			}
		}else{
			Local_u8ErrorState = MISSING_INFORM;
		}
	}else{
		Local_u8ErrorState = NULL_POINTER;
	}
	return Local_u8ErrorState;
}
//<------------------------------------------------------>

//<--------------------7 SEGMENT-------------------->
uint8 SSD_u8Enable(const SSD_Config_t* Copy_Pu8Object){
	uint8 Local_u8ErrorState = OK;
	if(Copy_Pu8Object != NULL){
		if(Copy_Pu8Object->Local_u8EnablePort != NULL && Copy_Pu8Object->Local_u8EnablePin != NULL && Copy_Pu8Object->Local_u8Type != NULL){
			if(Copy_Pu8Object->Local_u8EnablePin <= DIO_u8_PIN7){
				switch(Copy_Pu8Object->Local_u8EnablePort){
					case DIO_u8_PORTA :{
						if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_CATHODE)
							SET_BIT(DDRA,Copy_Pu8Object->Local_u8EnablePin);
						else if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_ANODE){
							CLR_BIT(DDRA,Copy_Pu8Object->Local_u8EnablePin);
						}
					} break;

					case DIO_u8_PORTB :{
						if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_CATHODE)
							SET_BIT(DDRB,Copy_Pu8Object->Local_u8EnablePin);
						else if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_ANODE){
							CLR_BIT(DDRB,Copy_Pu8Object->Local_u8EnablePin);
						}
					} break;

					case DIO_u8_PORTC : {
						if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_CATHODE)
							SET_BIT(DDRC,Copy_Pu8Object->Local_u8EnablePin);
						else if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_ANODE){
							CLR_BIT(DDRC,Copy_Pu8Object->Local_u8EnablePin);
						}
					} break;

					case DIO_u8_PORTD :{
						if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_CATHODE)
							SET_BIT(DDRD,Copy_Pu8Object->Local_u8EnablePin);
						else if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_ANODE){
							CLR_BIT(DDRD,Copy_Pu8Object->Local_u8EnablePin);
						}
					} break;

					default : Local_u8ErrorState = NOK; break;
				}
			}else{
				Local_u8ErrorState = NOK;
			}
		}else{
			Local_u8ErrorState = MISSING_INFORM;
		}
	}else{
		Local_u8ErrorState = NULL_POINTER;
	}
	return Local_u8ErrorState;
}

uint8 SSD_u8Disable(const SSD_Config_t* Copy_Pu8Object){
	uint8 Local_u8ErrorState = OK;
	if(Copy_Pu8Object != NULL){
		if(Copy_Pu8Object->Local_u8EnablePort != NULL && Copy_Pu8Object->Local_u8EnablePin != NULL && Copy_Pu8Object->Local_u8Type != NULL){
			if(Copy_Pu8Object->Local_u8EnablePin <= DIO_u8_PIN7){
				switch(Copy_Pu8Object->Local_u8EnablePort){
					case DIO_u8_PORTA :{
						if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_CATHODE)
							CLR_BIT(DDRA,Copy_Pu8Object->Local_u8EnablePin);
						else if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_ANODE){
							SET_BIT(DDRA,Copy_Pu8Object->Local_u8EnablePin);
						}
					} break;

					case DIO_u8_PORTB :{
						if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_CATHODE)
							CLR_BIT(DDRB,Copy_Pu8Object->Local_u8EnablePin);
						else if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_ANODE){
							SET_BIT(DDRB,Copy_Pu8Object->Local_u8EnablePin);
						}
					} break;

					case DIO_u8_PORTC : {
						if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_CATHODE)
							CLR_BIT(DDRC,Copy_Pu8Object->Local_u8EnablePin);
						else if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_ANODE){
							SET_BIT(DDRC,Copy_Pu8Object->Local_u8EnablePin);
						}
					} break;

					case DIO_u8_PORTD :{
						if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_CATHODE)
							CLR_BIT(DDRD,Copy_Pu8Object->Local_u8EnablePin);
						else if(Copy_Pu8Object->Local_u8Type == DIO_u8_SSD_TYPE_ANODE){
							SET_BIT(DDRD,Copy_Pu8Object->Local_u8EnablePin);
						}
					} break;

					default : Local_u8ErrorState = NOK; break;
				}
			}else{
				Local_u8ErrorState = NOK;
			}
		}else{
			Local_u8ErrorState = MISSING_INFORM;
		}
	}else{
		Local_u8ErrorState = NULL_POINTER;
	}
	return Local_u8ErrorState;
}

uint8 SSD_u8SetNumber(const SSD_Config_t* Copy_Pu8Object , uint8 Copy_u8Number){
	uint8 Local_u8ErrorState = OK;
	if(Copy_Pu8Object != NULL){
		if(Copy_Pu8Object->Local_u8DataPort != NULL && Copy_Pu8Object->Local_u8Type != NULL && Copy_Pu8Object->Local_u8PinA != NULL
				&& Copy_Pu8Object->Local_u8PinB != NULL && Copy_Pu8Object->Local_u8PinC != NULL && Copy_Pu8Object->Local_u8PinD != NULL){
			if(Copy_Pu8Object->Local_u8Type <= DIO_u8_SSD_TYPE_ANODE && Copy_Pu8Object->Local_u8PinA <= DIO_u8_PIN7 && Copy_Pu8Object->Local_u8PinB <= DIO_u8_PIN7
					&& Copy_Pu8Object->Local_u8PinC <= DIO_u8_PIN7 && Copy_Pu8Object->Local_u8PinD <= DIO_u8_PIN7){
				if(Copy_u8Number <= 9){
					switch(Copy_Pu8Object->Local_u8DataPort){

						case DIO_u8_PORTA : {
							SET_BIT(DDRA,Copy_Pu8Object->Local_u8PinA);
							SET_BIT(DDRA,Copy_Pu8Object->Local_u8PinB);
							SET_BIT(DDRA,Copy_Pu8Object->Local_u8PinC);
							SET_BIT(DDRA,Copy_Pu8Object->Local_u8PinD);

							ASSIGN_BIT(PORTA,Copy_Pu8Object->Local_u8PinA,GET_BIT(Copy_u8Number,0));
							ASSIGN_BIT(PORTA,Copy_Pu8Object->Local_u8PinB,GET_BIT(Copy_u8Number,1));
							ASSIGN_BIT(PORTA,Copy_Pu8Object->Local_u8PinC,GET_BIT(Copy_u8Number,2));
							ASSIGN_BIT(PORTA,Copy_Pu8Object->Local_u8PinD,GET_BIT(Copy_u8Number,3));

						} break;

						case DIO_u8_PORTB : {
							SET_BIT(DDRB,Copy_Pu8Object->Local_u8PinA);
							SET_BIT(DDRB,Copy_Pu8Object->Local_u8PinB);
							SET_BIT(DDRB,Copy_Pu8Object->Local_u8PinC);
							SET_BIT(DDRB,Copy_Pu8Object->Local_u8PinD);

							ASSIGN_BIT(PORTB,Copy_Pu8Object->Local_u8PinA,GET_BIT(Copy_u8Number,0));
							ASSIGN_BIT(PORTB,Copy_Pu8Object->Local_u8PinB,GET_BIT(Copy_u8Number,1));
							ASSIGN_BIT(PORTB,Copy_Pu8Object->Local_u8PinC,GET_BIT(Copy_u8Number,2));
							ASSIGN_BIT(PORTB,Copy_Pu8Object->Local_u8PinD,GET_BIT(Copy_u8Number,3));

						}break;

						case DIO_u8_PORTC : {
							SET_BIT(DDRC,Copy_Pu8Object->Local_u8PinA);
							SET_BIT(DDRC,Copy_Pu8Object->Local_u8PinB);
							SET_BIT(DDRC,Copy_Pu8Object->Local_u8PinC);
							SET_BIT(DDRC,Copy_Pu8Object->Local_u8PinD);

							ASSIGN_BIT(PORTC,Copy_Pu8Object->Local_u8PinA,GET_BIT(Copy_u8Number,0));
							ASSIGN_BIT(PORTC,Copy_Pu8Object->Local_u8PinB,GET_BIT(Copy_u8Number,1));
							ASSIGN_BIT(PORTC,Copy_Pu8Object->Local_u8PinC,GET_BIT(Copy_u8Number,2));
							ASSIGN_BIT(PORTC,Copy_Pu8Object->Local_u8PinD,GET_BIT(Copy_u8Number,3));

						} break;

						case DIO_u8_PORTD : {
							SET_BIT(DDRD,Copy_Pu8Object->Local_u8PinA);
							SET_BIT(DDRD,Copy_Pu8Object->Local_u8PinB);
							SET_BIT(DDRD,Copy_Pu8Object->Local_u8PinC);
							SET_BIT(DDRD,Copy_Pu8Object->Local_u8PinD);

							ASSIGN_BIT(PORTD,Copy_Pu8Object->Local_u8PinA,GET_BIT(Copy_u8Number,0));
							ASSIGN_BIT(PORTD,Copy_Pu8Object->Local_u8PinB,GET_BIT(Copy_u8Number,1));
							ASSIGN_BIT(PORTD,Copy_Pu8Object->Local_u8PinC,GET_BIT(Copy_u8Number,2));
							ASSIGN_BIT(PORTD,Copy_Pu8Object->Local_u8PinD,GET_BIT(Copy_u8Number,3));

						} break;

						default : Local_u8ErrorState = NOK; break;
					}
				}else{
					Local_u8ErrorState = BIG_NUM;
				}
			}else{
				Local_u8ErrorState = NOK;
			}
		}else{
			Local_u8ErrorState = MISSING_INFORM;
		}
	}else{
		Local_u8ErrorState = NULL_POINTER;
	}
	return Local_u8ErrorState;
}
//<------------------------------------------------------>
