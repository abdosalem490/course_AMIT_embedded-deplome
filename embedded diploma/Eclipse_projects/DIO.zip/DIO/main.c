#include "STD_TYPES.h"
#include "BTT_MATH.h"
#include "ERR_TYPE.h"

#include "DIO_interface.h"
#include<util/delay.h>

int main(){

	DIO_u8SetPinDirection(DIO_u8_PORTD,DIO_u8_PIN2,DIO_u8_PIN_INPUT);
	DIO_u8SetPinDirection(DIO_u8_PORTD,DIO_u8_PIN3,DIO_u8_PIN_OUTPUT);
	uint8 DIO_u8Button2Clicked = 0;
	DIO_u8SetPinValue(DIO_u8_PORTD,DIO_u8_PIN3,DIO_u8_PIN_HIGH);
	while(1){
		if(DIO_u8ReadPinValue(DIO_u8_PORTD,DIO_u8_PIN2,&DIO_u8Button2Clicked) == OK){
			if(DIO_u8Button2Clicked == DIO_u8_PIN_HIGH){
				_delay_ms(250);
				DIO_u8TogglePinValue(DIO_u8_PORTD,DIO_u8_PIN3);
			}
		}

	}


	return 0;
}
