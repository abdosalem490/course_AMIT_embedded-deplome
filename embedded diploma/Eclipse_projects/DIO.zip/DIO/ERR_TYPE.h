#ifndef ERR_TYPE_H_
#define ERR_TYPE_H_

#define NULL			0xffff

#define OK			    0
#define NOK 			1
#define NULL_POINTER  	2
#define MISSING_INFORM 	3
#define BIG_NUM			4

#endif
